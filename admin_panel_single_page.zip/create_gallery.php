<?php include 'config.php'; ?>
<form method="POST">
    <input type="text" name="name" placeholder="Име на галерията" required>
    <input type="number" name="year" placeholder="Година (напр. 2024)" required>
    <button type="submit" name="submit">Създай галерия</button>
</form>
<?php
if (isset($_POST['submit'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $year = intval($_POST['year']);
    $sql = "INSERT INTO galleries (name, year) VALUES ('$name', $year)";
    if ($conn->query($sql)) {
        echo "Галерията е създадена успешно!";
    } else {
        echo "Грешка: " . $conn->error;
    }
}
?>