<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="UTF-8">
    <title>Админ панел – Нова галерия</title>
</head>
<body>
    <h1>Създай галерия и качи снимки</h1>
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="name" placeholder="Име на галерията" required><br><br>
        <input type="number" name="year" placeholder="Година (напр. 2024)" required><br><br>
        <input type="file" name="photos[]" multiple required><br><br>
        <button type="submit" name="submit">Създай галерия и качи снимки</button>
    </form>
    <br>
    <?php
    if (isset($_POST['submit'])) {
        $name = $conn->real_escape_string($_POST['name']);
        $year = intval($_POST['year']);

        // Създаване на нова галерия
        $sql = "INSERT INTO galleries (name, year) VALUES ('$name', $year)";
        if ($conn->query($sql)) {
            $gallery_id = $conn->insert_id;

            // Качване на снимки
            foreach ($_FILES['photos']['tmp_name'] as $key => $tmp_name) {
                $fileName = basename($_FILES['photos']['name'][$key]);
                $targetPath = "uploads/" . $fileName;

                if (move_uploaded_file($tmp_name, $targetPath)) {
                    $conn->query("INSERT INTO photos (gallery_id, title, image_path) VALUES ($gallery_id, '$fileName', '$targetPath')");
                }
            }
            echo "<p style='color:green;'>Галерията и снимките са създадени успешно!</p>";
        } else {
            echo "<p style='color:red;'>Грешка при създаване на галерия: " . $conn->error . "</p>";
        }
    }
    ?>
</body>
</html>
