<?php include 'config.php'; ?>
<form method="POST" enctype="multipart/form-data">
    <select name="gallery_id" required>
        <option value="">Избери галерия</option>
        <?php
        $result = $conn->query("SELECT id, name FROM galleries ORDER BY created_at DESC");
        while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['id']}'>{$row['name']}</option>";
        }
        ?>
    </select>
    <input type="file" name="photos[]" multiple required>
    <button type="submit" name="upload">Качи снимки</button>
</form>
<?php
if (isset($_POST['upload'])) {
    $gallery_id = intval($_POST['gallery_id']);
    foreach ($_FILES['photos']['tmp_name'] as $key => $tmp_name) {
        $fileName = basename($_FILES['photos']['name'][$key]);
        $targetPath = "uploads/" . $fileName;
        if (move_uploaded_file($tmp_name, $targetPath)) {
            $conn->query("INSERT INTO photos (gallery_id, title, image_path) VALUES ($gallery_id, '$fileName', '$targetPath')");
        }
    }
    echo "Снимките са качени!";
}
?>